using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.DTOs;

namespace RaceDay.Tests;

public class ResultTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public ResultTests(RaceDayFactory factory) => _factory = factory;

    private async Task<(HttpClient Organiser, HttpClient Participant, EventDto Event, EnrolmentDto Enrolment)> ArrangeAsync()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var participant = await _factory.LoginParticipantAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        var category = await RaceDayFactory.CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await RaceDayFactory.EnrolAsync(participant, ev.EventId, category.CategoryId);
        return (organiser, participant, ev, enrolment);
    }

    [Fact]
    public async Task Organiser_CanCaptureResult_AndParticipantCanViewIt()
    {
        var (organiser, participant, ev, enrolment) = await ArrangeAsync();

        var capture = await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results",
            new { enrolmentId = enrolment.EnrolmentId, finishTime = "01:45:30", finishPosition = 3 });

        Assert.Equal(HttpStatusCode.Created, capture.StatusCode);
        var created = await capture.ReadAsync<ResultDto>();
        Assert.Equal("01:45:30", created.FinishTime);
        Assert.Equal(3, created.FinishPosition);

        var mine = await (await participant.GetAsync("/api/results/mine")).ReadAsync<List<ResultDto>>();
        Assert.Contains(mine, r => r.ResultId == created.ResultId);
    }

    [Fact]
    public async Task Participant_CannotCaptureResult()
    {
        var (_, participant, ev, enrolment) = await ArrangeAsync();

        var response = await participant.PostAsJsonAsync($"/api/events/{ev.EventId}/results",
            new { enrolmentId = enrolment.EnrolmentId, finishTime = "01:00:00", finishPosition = 1 });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotCaptureResultForAnotherOrganisersEvent()
    {
        var (_, _, ev, enrolment) = await ArrangeAsync();
        var other = await _factory.LoginOrganiserAsync();

        var response = await other.PostAsJsonAsync($"/api/events/{ev.EventId}/results",
            new { enrolmentId = enrolment.EnrolmentId, finishTime = "01:00:00", finishPosition = 1 });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_InvalidTimeFormat_ReturnsBadRequest()
    {
        var (organiser, _, ev, enrolment) = await ArrangeAsync();

        var response = await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results",
            new { enrolmentId = enrolment.EnrolmentId, finishTime = "fast", finishPosition = 1 });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_InvalidPosition_ReturnsBadRequest()
    {
        var (organiser, _, ev, enrolment) = await ArrangeAsync();

        var response = await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results",
            new { enrolmentId = enrolment.EnrolmentId, finishTime = "01:00:00", finishPosition = 0 });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_EnrolmentFromAnotherEvent_ReturnsBadRequest()
    {
        var (organiser, _, _, enrolment) = await ArrangeAsync();
        var otherEvent = await RaceDayFactory.CreateEventAsync(organiser);

        var response = await organiser.PostAsJsonAsync($"/api/events/{otherEvent.EventId}/results",
            new { enrolmentId = enrolment.EnrolmentId, finishTime = "01:00:00", finishPosition = 1 });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_Twice_ReturnsConflict()
    {
        var (organiser, _, ev, enrolment) = await ArrangeAsync();
        var body = new { enrolmentId = enrolment.EnrolmentId, finishTime = "01:00:00", finishPosition = 1 };
        await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results", body);

        var second = await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results", body);

        Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
    }

    [Fact]
    public async Task CaptureResult_DuplicatePositionInSameEvent_ReturnsConflict()
    {
        var (organiser, _, ev, enrolment) = await ArrangeAsync();
        var secondParticipant = await _factory.LoginParticipantAsync();
        var category = (await (await organiser.GetAsync($"/api/events/{ev.EventId}/categories")).ReadAsync<List<CategoryDto>>()).First();
        var secondEnrolment = await RaceDayFactory.EnrolAsync(secondParticipant, ev.EventId, category.CategoryId);

        await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results",
            new { enrolmentId = enrolment.EnrolmentId, finishTime = "01:00:00", finishPosition = 1 });
        var response = await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results",
            new { enrolmentId = secondEnrolment.EnrolmentId, finishTime = "01:05:00", finishPosition = 1 });

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanViewResultsOrderedByPosition()
    {
        var (organiser, _, ev, enrolment) = await ArrangeAsync();
        var secondParticipant = await _factory.LoginParticipantAsync();
        var category = (await (await organiser.GetAsync($"/api/events/{ev.EventId}/categories")).ReadAsync<List<CategoryDto>>()).First();
        var secondEnrolment = await RaceDayFactory.EnrolAsync(secondParticipant, ev.EventId, category.CategoryId);

        await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results",
            new { enrolmentId = enrolment.EnrolmentId, finishTime = "01:20:00", finishPosition = 2 });
        await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results",
            new { enrolmentId = secondEnrolment.EnrolmentId, finishTime = "01:10:00", finishPosition = 1 });

        var response = await organiser.GetAsync($"/api/events/{ev.EventId}/results");
        var results = await response.ReadAsync<List<ResultDto>>();

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal(new[] { 1, 2 }, results.Select(r => r.FinishPosition).ToArray());
    }

    [Fact]
    public async Task Participant_CannotViewEventResultsList()
    {
        var (_, participant, ev, _) = await ArrangeAsync();

        var response = await participant.GetAsync($"/api/events/{ev.EventId}/results");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_OnlySeesOwnResults()
    {
        var (organiser, _, ev, enrolment) = await ArrangeAsync();
        var otherParticipant = await _factory.LoginParticipantAsync();
        await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results",
            new { enrolmentId = enrolment.EnrolmentId, finishTime = "02:00:00", finishPosition = 1 });

        var otherResults = await (await otherParticipant.GetAsync("/api/results/mine")).ReadAsync<List<ResultDto>>();

        Assert.Empty(otherResults);
    }

    [Fact]
    public async Task Organiser_CanCorrectAResult()
    {
        var (organiser, _, ev, enrolment) = await ArrangeAsync();
        var created = await (await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results",
            new { enrolmentId = enrolment.EnrolmentId, finishTime = "02:00:00", finishPosition = 5 })).ReadAsync<ResultDto>();

        var update = await organiser.PutAsJsonAsync($"/api/results/{created.ResultId}", new { finishTime = "01:59:59", finishPosition = 4 });

        Assert.Equal(HttpStatusCode.OK, update.StatusCode);
        var updated = await update.ReadAsync<ResultDto>();
        Assert.Equal("01:59:59", updated.FinishTime);
        Assert.Equal(4, updated.FinishPosition);
    }

    [Fact]
    public async Task Participant_CannotCorrectAResult()
    {
        var (organiser, participant, ev, enrolment) = await ArrangeAsync();
        var created = await (await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results",
            new { enrolmentId = enrolment.EnrolmentId, finishTime = "02:00:00", finishPosition = 5 })).ReadAsync<ResultDto>();

        var update = await participant.PutAsJsonAsync($"/api/results/{created.ResultId}", new { finishTime = "00:30:00", finishPosition = 1 });

        Assert.Equal(HttpStatusCode.Forbidden, update.StatusCode);
    }

    [Fact]
    public async Task UpdateResult_UnknownId_ReturnsNotFound()
    {
        var organiser = await _factory.LoginOrganiserAsync();

        var response = await organiser.PutAsJsonAsync("/api/results/999999", new { finishTime = "01:00:00", finishPosition = 1 });

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }
}
