using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.DTOs;

namespace RaceDay.Tests;

public class EnrolmentTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public EnrolmentTests(RaceDayFactory factory) => _factory = factory;

    [Fact]
    public async Task Participant_CanEnterEventByCategory_AndSeeItInOwnEnrolments()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var participant = await _factory.LoginParticipantAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        var category = await RaceDayFactory.CreateCategoryAsync(organiser, ev.EventId);

        var response = await participant.PostAsJsonAsync("/api/enrolments", new { eventId = ev.EventId, categoryId = category.CategoryId });
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var enrolment = await response.ReadAsync<EnrolmentDto>();
        Assert.Equal(category.CategoryId, enrolment.CategoryId);

        var mine = await (await participant.GetAsync("/api/enrolments/mine")).ReadAsync<List<EnrolmentDto>>();
        Assert.Contains(mine, e => e.EnrolmentId == enrolment.EnrolmentId);
    }

    [Fact]
    public async Task Participant_CannotEnterSameEventTwice()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var participant = await _factory.LoginParticipantAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        var category = await RaceDayFactory.CreateCategoryAsync(organiser, ev.EventId);
        await RaceDayFactory.EnrolAsync(participant, ev.EventId, category.CategoryId);

        var second = await participant.PostAsJsonAsync("/api/enrolments", new { eventId = ev.EventId, categoryId = category.CategoryId });

        Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
    }

    [Fact]
    public async Task Enrol_WithCategoryFromAnotherEvent_ReturnsBadRequest()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var participant = await _factory.LoginParticipantAsync();
        var eventA = await RaceDayFactory.CreateEventAsync(organiser);
        var eventB = await RaceDayFactory.CreateEventAsync(organiser);
        var categoryOfB = await RaceDayFactory.CreateCategoryAsync(organiser, eventB.EventId);

        var response = await participant.PostAsJsonAsync("/api/enrolments", new { eventId = eventA.EventId, categoryId = categoryOfB.CategoryId });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Enrol_UnknownEvent_ReturnsNotFound()
    {
        var participant = await _factory.LoginParticipantAsync();

        var response = await participant.PostAsJsonAsync("/api/enrolments", new { eventId = 999999, categoryId = 1 });

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Enrol_EventAlreadyTookPlace_ReturnsBadRequest()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var participant = await _factory.LoginParticipantAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser, DateTime.UtcNow.AddDays(-3));
        var category = await RaceDayFactory.CreateCategoryAsync(organiser, ev.EventId);

        var response = await participant.PostAsJsonAsync("/api/enrolments", new { eventId = ev.EventId, categoryId = category.CategoryId });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotEnterAnEvent()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        var category = await RaceDayFactory.CreateCategoryAsync(organiser, ev.EventId);

        var response = await organiser.PostAsJsonAsync("/api/enrolments", new { eventId = ev.EventId, categoryId = category.CategoryId });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Anonymous_CannotEnterAnEvent()
    {
        var response = await _factory.NewClient().PostAsJsonAsync("/api/enrolments", new { eventId = 1, categoryId = 1 });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Participant_OnlySeesOwnEnrolments()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var first = await _factory.LoginParticipantAsync();
        var second = await _factory.LoginParticipantAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        var category = await RaceDayFactory.CreateCategoryAsync(organiser, ev.EventId);
        var firstEnrolment = await RaceDayFactory.EnrolAsync(first, ev.EventId, category.CategoryId);

        var secondList = await (await second.GetAsync("/api/enrolments/mine")).ReadAsync<List<EnrolmentDto>>();

        Assert.DoesNotContain(secondList, e => e.EnrolmentId == firstEnrolment.EnrolmentId);
    }

    [Fact]
    public async Task Organiser_CanViewAllEnrolmentsForOwnEvent()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var p1 = await _factory.LoginParticipantAsync();
        var p2 = await _factory.LoginParticipantAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        var category = await RaceDayFactory.CreateCategoryAsync(organiser, ev.EventId);
        await RaceDayFactory.EnrolAsync(p1, ev.EventId, category.CategoryId);
        await RaceDayFactory.EnrolAsync(p2, ev.EventId, category.CategoryId);

        var response = await organiser.GetAsync($"/api/events/{ev.EventId}/enrolments");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal(2, (await response.ReadAsync<List<EnrolmentDto>>()).Count);
    }

    [Fact]
    public async Task Organiser_CannotViewEnrolmentsOfAnotherOrganisersEvent()
    {
        var owner = await _factory.LoginOrganiserAsync();
        var other = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(owner);

        var response = await other.GetAsync($"/api/events/{ev.EventId}/enrolments");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotViewAllEnrolmentsForAnEvent()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var participant = await _factory.LoginParticipantAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);

        var response = await participant.GetAsync($"/api/events/{ev.EventId}/enrolments");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}
