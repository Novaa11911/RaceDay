using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.DTOs;

namespace RaceDay.Tests;

public class EventTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public EventTests(RaceDayFactory factory) => _factory = factory;

    [Fact]
    public async Task Organiser_CanCreateEvent()
    {
        var organiser = await _factory.LoginOrganiserAsync();

        var response = await organiser.PostAsJsonAsync("/api/events", RaceDayFactory.NewEventBody());

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var ev = await response.ReadAsync<EventDto>();
        Assert.Equal("Soweto Marathon Test", ev.Name);
        Assert.Equal(Api.Models.EventType.Run, ev.EventType);
        Assert.True(ev.EventId > 0);
    }

    [Fact]
    public async Task Participant_CannotCreateEvent()
    {
        var participant = await _factory.LoginParticipantAsync();

        var response = await participant.PostAsJsonAsync("/api/events", RaceDayFactory.NewEventBody());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Anonymous_CannotCreateEvent()
    {
        var client = _factory.NewClient();

        var response = await client.PostAsJsonAsync("/api/events", RaceDayFactory.NewEventBody());

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task CreateEvent_WithInvalidData_ReturnsBadRequest()
    {
        var organiser = await _factory.LoginOrganiserAsync();

        var response = await organiser.PostAsJsonAsync("/api/events", new
        {
            name = "",
            description = "x",
            eventDate = DateTime.UtcNow.AddDays(5),
            location = "Cape Town",
            distanceKm = -5,
            eventType = "Run"
        });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CanBrowseAndViewEvents()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        var participant = await _factory.LoginParticipantAsync();

        var list = await participant.GetAsync("/api/events");
        var single = await participant.GetAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.OK, list.StatusCode);
        Assert.Contains(await list.ReadAsync<List<EventDto>>(), e => e.EventId == ev.EventId);
        Assert.Equal(HttpStatusCode.OK, single.StatusCode);
    }

    [Fact]
    public async Task GetEvents_CanFilterByType()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var run = await RaceDayFactory.CreateEventAsync(organiser);
        var cycleResponse = await organiser.PostAsJsonAsync("/api/events", new
        {
            name = "Cycle Tour Test",
            description = "Cycle",
            eventDate = DateTime.UtcNow.AddDays(40),
            location = "Cape Town",
            distanceKm = 109,
            eventType = "Cycle"
        });
        var cycle = await cycleResponse.ReadAsync<EventDto>();

        var response = await organiser.GetAsync("/api/events?type=Cycle");
        var events = await response.ReadAsync<List<EventDto>>();

        Assert.Contains(events, e => e.EventId == cycle.EventId);
        Assert.DoesNotContain(events, e => e.EventId == run.EventId);
    }

    [Fact]
    public async Task GetEvent_UnknownId_ReturnsNotFound()
    {
        var participant = await _factory.LoginParticipantAsync();

        var response = await participant.GetAsync("/api/events/999999");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanUpdateOwnEvent()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);

        var response = await organiser.PutAsJsonAsync($"/api/events/{ev.EventId}", new
        {
            name = "Renamed Event",
            description = "Updated",
            eventDate = DateTime.UtcNow.AddDays(60),
            location = "Durban",
            distanceKm = 21.1,
            eventType = "Walk"
        });

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var updated = await response.ReadAsync<EventDto>();
        Assert.Equal("Renamed Event", updated.Name);
        Assert.Equal(Api.Models.EventType.Walk, updated.EventType);
    }

    [Fact]
    public async Task Organiser_CannotUpdateAnotherOrganisersEvent()
    {
        var owner = await _factory.LoginOrganiserAsync();
        var other = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(owner);

        var response = await other.PutAsJsonAsync($"/api/events/{ev.EventId}", RaceDayFactory.NewEventBody());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotUpdateEvent()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        var participant = await _factory.LoginParticipantAsync();

        var response = await participant.PutAsJsonAsync($"/api/events/{ev.EventId}", RaceDayFactory.NewEventBody());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanDeleteOwnEvent()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        await RaceDayFactory.CreateCategoryAsync(organiser, ev.EventId);

        var delete = await organiser.DeleteAsync($"/api/events/{ev.EventId}");
        var get = await organiser.GetAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.NoContent, delete.StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, get.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanDeleteEventThatHasEnrolmentsAndResults()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var participant = await _factory.LoginParticipantAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        var category = await RaceDayFactory.CreateCategoryAsync(organiser, ev.EventId);
        var enrolment = await RaceDayFactory.EnrolAsync(participant, ev.EventId, category.CategoryId);
        await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/results", new { enrolmentId = enrolment.EnrolmentId, finishTime = "02:30:00", finishPosition = 1 });

        var delete = await organiser.DeleteAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.NoContent, delete.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotDeleteAnotherOrganisersEvent()
    {
        var owner = await _factory.LoginOrganiserAsync();
        var other = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(owner);

        var response = await other.DeleteAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotDeleteEvent()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        var participant = await _factory.LoginParticipantAsync();

        var response = await participant.DeleteAsync($"/api/events/{ev.EventId}");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Delete_UnknownEvent_ReturnsNotFound()
    {
        var organiser = await _factory.LoginOrganiserAsync();

        var response = await organiser.DeleteAsync("/api/events/999999");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }
}
