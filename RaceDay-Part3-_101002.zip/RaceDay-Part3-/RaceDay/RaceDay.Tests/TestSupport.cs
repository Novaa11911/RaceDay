using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;

namespace RaceDay.Tests;

/// <summary>Runs the real API in memory, using an in-memory database instead of SQL Server.</summary>
public class RaceDayFactory : WebApplicationFactory<Program>
{
    public const string OrganiserCode = "TEST-ORGANISER-CODE";
    private readonly string _dbName = Guid.NewGuid().ToString();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");

        builder.ConfigureAppConfiguration((_, config) =>
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Registration:OrganiserCode"] = OrganiserCode
            }));

        builder.ConfigureServices(services =>
        {
            var existing = services.SingleOrDefault(d => d.ServiceType == typeof(DbContextOptions<AppDbContext>));
            if (existing is not null)
                services.Remove(existing);

            services.AddDbContext<AppDbContext>(o => o.UseInMemoryDatabase(_dbName));
        });
    }

    public HttpClient NewClient() =>
        CreateClient(new WebApplicationFactoryClientOptions { HandleCookies = true, AllowAutoRedirect = false });

    /// <summary>Registers a new user with the given role, logs them in and returns a client that holds their session cookie.</summary>
    public async Task<(HttpClient Client, string Email)> LoginAsync(string role)
    {
        var client = NewClient();
        var email = $"{role.ToLower()}-{Guid.NewGuid():N}@raceday.test";

        var register = await client.PostAsJsonAsync("/api/auth/register", new
        {
            firstName = "Test",
            lastName = role,
            email,
            password = "Passw0rd!",
            role,
            organiserCode = role == "Organiser" ? OrganiserCode : null
        });
        register.EnsureSuccessStatusCode();

        var login = await client.PostAsJsonAsync("/api/auth/login", new { email, password = "Passw0rd!" });
        login.EnsureSuccessStatusCode();

        return (client, email);
    }

    public async Task<HttpClient> LoginOrganiserAsync() => (await LoginAsync("Organiser")).Client;
    public async Task<HttpClient> LoginParticipantAsync() => (await LoginAsync("Participant")).Client;

    // ---- shortcuts for building test data ----
    public static object NewEventBody(DateTime? date = null) => new
    {
        name = "Soweto Marathon Test",
        description = "A test event",
        eventDate = date ?? DateTime.UtcNow.AddDays(30),
        location = "Soweto",
        distanceKm = 42.2,
        eventType = "Run"
    };

    public static async Task<EventDto> CreateEventAsync(HttpClient organiser, DateTime? date = null)
    {
        var response = await organiser.PostAsJsonAsync("/api/events", NewEventBody(date));
        response.EnsureSuccessStatusCode();
        return await response.ReadAsync<EventDto>();
    }

    public static async Task<CategoryDto> CreateCategoryAsync(HttpClient organiser, int eventId, string name = "Senior")
    {
        var response = await organiser.PostAsJsonAsync($"/api/events/{eventId}/categories", new { name, categoryType = "Age" });
        response.EnsureSuccessStatusCode();
        return await response.ReadAsync<CategoryDto>();
    }

    public static async Task<EnrolmentDto> EnrolAsync(HttpClient participant, int eventId, int categoryId)
    {
        var response = await participant.PostAsJsonAsync("/api/enrolments", new { eventId, categoryId });
        response.EnsureSuccessStatusCode();
        return await response.ReadAsync<EnrolmentDto>();
    }
}

public static class HttpExtensions
{
    public static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        Converters = { new JsonStringEnumConverter() }
    };

    public static async Task<T> ReadAsync<T>(this HttpResponseMessage response)
    {
        var value = await response.Content.ReadFromJsonAsync<T>(JsonOptions);
        return value ?? throw new InvalidOperationException("Response body was empty.");
    }
}
