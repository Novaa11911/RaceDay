using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.DTOs;

namespace RaceDay.Tests;

public class CategoryTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public CategoryTests(RaceDayFactory factory) => _factory = factory;

    [Fact]
    public async Task Organiser_CanCreateCategory_AndBothRolesCanView()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var participant = await _factory.LoginParticipantAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);

        var create = await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/categories", new { name = "Under 20", categoryType = "Age" });
        Assert.Equal(HttpStatusCode.Created, create.StatusCode);
        var created = await create.ReadAsync<CategoryDto>();

        foreach (var client in new[] { organiser, participant })
        {
            var list = await client.GetAsync($"/api/events/{ev.EventId}/categories");
            Assert.Equal(HttpStatusCode.OK, list.StatusCode);
            Assert.Contains(await list.ReadAsync<List<CategoryDto>>(), c => c.CategoryId == created.CategoryId && c.Name == "Under 20");
        }
    }

    [Fact]
    public async Task Participant_CannotCreateCategory()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var participant = await _factory.LoginParticipantAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);

        var response = await participant.PostAsJsonAsync($"/api/events/{ev.EventId}/categories", new { name = "10km", categoryType = "Distance" });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotCreateCategoryForAnotherOrganisersEvent()
    {
        var owner = await _factory.LoginOrganiserAsync();
        var other = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(owner);

        var response = await other.PostAsJsonAsync($"/api/events/{ev.EventId}/categories", new { name = "10km", categoryType = "Distance" });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task CreateCategory_DuplicateName_ReturnsConflict()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        await RaceDayFactory.CreateCategoryAsync(organiser, ev.EventId, "Senior");

        var response = await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/categories", new { name = "Senior", categoryType = "Age" });

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task CreateCategory_EmptyName_ReturnsBadRequest()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);

        var response = await organiser.PostAsJsonAsync($"/api/events/{ev.EventId}/categories", new { name = "", categoryType = "Age" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task GetCategories_UnknownEvent_ReturnsNotFound()
    {
        var participant = await _factory.LoginParticipantAsync();

        var response = await participant.GetAsync("/api/events/999999/categories");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanUpdateAndDeleteUnusedCategory()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        var category = await RaceDayFactory.CreateCategoryAsync(organiser, ev.EventId, "Junior");

        var update = await organiser.PutAsJsonAsync($"/api/events/{ev.EventId}/categories/{category.CategoryId}", new { name = "Youth", categoryType = "Age" });
        Assert.Equal(HttpStatusCode.OK, update.StatusCode);
        Assert.Equal("Youth", (await update.ReadAsync<CategoryDto>()).Name);

        var delete = await organiser.DeleteAsync($"/api/events/{ev.EventId}/categories/{category.CategoryId}");
        Assert.Equal(HttpStatusCode.NoContent, delete.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotDeleteCategoryThatHasEnrolments()
    {
        var organiser = await _factory.LoginOrganiserAsync();
        var participant = await _factory.LoginParticipantAsync();
        var ev = await RaceDayFactory.CreateEventAsync(organiser);
        var category = await RaceDayFactory.CreateCategoryAsync(organiser, ev.EventId);
        await RaceDayFactory.EnrolAsync(participant, ev.EventId, category.CategoryId);

        var response = await organiser.DeleteAsync($"/api/events/{ev.EventId}/categories/{category.CategoryId}");

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }
}
