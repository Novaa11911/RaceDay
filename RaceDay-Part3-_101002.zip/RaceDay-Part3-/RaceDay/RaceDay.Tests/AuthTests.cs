using System.Net;
using System.Net.Http.Json;
using Microsoft.Extensions.DependencyInjection;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Tests;

public class AuthTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public AuthTests(RaceDayFactory factory) => _factory = factory;

    private static object RegisterBody(string email, string role = "Participant", string? code = null, string password = "Passw0rd!") => new
    {
        firstName = "Thabo",
        lastName = "Mokoena",
        email,
        password,
        role,
        organiserCode = code
    };

    [Fact]
    public async Task Register_Participant_ReturnsCreatedWithoutPassword()
    {
        var client = _factory.NewClient();
        var email = $"p-{Guid.NewGuid():N}@raceday.test";

        var response = await client.PostAsJsonAsync("/api/auth/register", RegisterBody(email));

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var body = await response.Content.ReadAsStringAsync();
        Assert.DoesNotContain("password", body, StringComparison.OrdinalIgnoreCase);
        var user = await response.ReadAsync<UserDto>();
        Assert.Equal("Participant", user.Role);
        Assert.Equal(email, user.Email);
    }

    [Fact]
    public async Task Register_OrganiserWithValidCode_ReturnsCreated()
    {
        var client = _factory.NewClient();
        var response = await client.PostAsJsonAsync("/api/auth/register",
            RegisterBody($"o-{Guid.NewGuid():N}@raceday.test", "Organiser", RaceDayFactory.OrganiserCode));

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
    }

    [Fact]
    public async Task Register_OrganiserWithoutCode_ReturnsForbidden()
    {
        var client = _factory.NewClient();
        var response = await client.PostAsJsonAsync("/api/auth/register",
            RegisterBody($"o-{Guid.NewGuid():N}@raceday.test", "Organiser"));

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Register_OrganiserWithWrongCode_ReturnsForbidden()
    {
        var client = _factory.NewClient();
        var response = await client.PostAsJsonAsync("/api/auth/register",
            RegisterBody($"o-{Guid.NewGuid():N}@raceday.test", "Organiser", "WRONG-CODE"));

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Register_InvalidRole_ReturnsBadRequest()
    {
        var client = _factory.NewClient();
        var response = await client.PostAsJsonAsync("/api/auth/register",
            RegisterBody($"x-{Guid.NewGuid():N}@raceday.test", "Admin"));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_ShortPassword_ReturnsBadRequest()
    {
        var client = _factory.NewClient();
        var response = await client.PostAsJsonAsync("/api/auth/register",
            RegisterBody($"x-{Guid.NewGuid():N}@raceday.test", password: "short"));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_InvalidEmail_ReturnsBadRequest()
    {
        var client = _factory.NewClient();
        var response = await client.PostAsJsonAsync("/api/auth/register", RegisterBody("not-an-email"));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Register_DuplicateEmail_ReturnsConflict()
    {
        var client = _factory.NewClient();
        var email = $"dup-{Guid.NewGuid():N}@raceday.test";

        var first = await client.PostAsJsonAsync("/api/auth/register", RegisterBody(email));
        var second = await client.PostAsJsonAsync("/api/auth/register", RegisterBody(email.ToUpperInvariant()));

        Assert.Equal(HttpStatusCode.Created, first.StatusCode);
        Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
    }

    [Fact]
    public async Task Register_StoresHashedPassword_NotPlainText()
    {
        var client = _factory.NewClient();
        var email = $"hash-{Guid.NewGuid():N}@raceday.test";
        await client.PostAsJsonAsync("/api/auth/register", RegisterBody(email));

        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var passwords = scope.ServiceProvider.GetRequiredService<IPasswordService>();
        var user = db.Users.Single(u => u.Email == email);

        Assert.NotEqual("Passw0rd!", user.PasswordHash);
        Assert.DoesNotContain("Passw0rd!", user.PasswordHash);
        Assert.True(passwords.Verify("Passw0rd!", user.PasswordHash));
        Assert.False(passwords.Verify("WrongPassword", user.PasswordHash));
    }

    [Fact]
    public async Task Login_ValidCredentials_ReturnsOkAndCanAccessProtectedEndpoint()
    {
        var (client, _) = await _factory.LoginAsync("Participant");

        var response = await client.GetAsync("/api/events");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    [Fact]
    public async Task Login_WrongPassword_ReturnsUnauthorized()
    {
        var client = _factory.NewClient();
        var email = $"login-{Guid.NewGuid():N}@raceday.test";
        await client.PostAsJsonAsync("/api/auth/register", RegisterBody(email));

        var response = await client.PostAsJsonAsync("/api/auth/login", new { email, password = "WrongPassword1" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Login_UnknownUser_ReturnsUnauthorized()
    {
        var client = _factory.NewClient();
        var response = await client.PostAsJsonAsync("/api/auth/login", new { email = "nobody@raceday.test", password = "Passw0rd!" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Theory]
    [InlineData("/api/events")]
    [InlineData("/api/profile")]
    [InlineData("/api/enrolments/mine")]
    [InlineData("/api/results/mine")]
    public async Task ProtectedEndpoints_WithoutLogin_ReturnUnauthorized(string url)
    {
        var client = _factory.NewClient();

        var response = await client.GetAsync(url);

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Logout_EndsSession()
    {
        var (client, _) = await _factory.LoginAsync("Participant");
        Assert.Equal(HttpStatusCode.OK, (await client.GetAsync("/api/events")).StatusCode);

        var logout = await client.PostAsync("/api/auth/logout", null);
        Assert.Equal(HttpStatusCode.NoContent, logout.StatusCode);

        Assert.Equal(HttpStatusCode.Unauthorized, (await client.GetAsync("/api/events")).StatusCode);
    }

    [Fact]
    public async Task Profile_UserCanViewAndUpdateOwnProfile()
    {
        var (client, email) = await _factory.LoginAsync("Participant");

        var view = await client.GetAsync("/api/profile");
        Assert.Equal(HttpStatusCode.OK, view.StatusCode);
        Assert.Equal(email, (await view.ReadAsync<UserDto>()).Email);

        var update = await client.PutAsJsonAsync("/api/profile", new { firstName = "Lerato", lastName = "Dlamini", phoneNumber = "0821234567" });
        Assert.Equal(HttpStatusCode.OK, update.StatusCode);

        var updated = await (await client.GetAsync("/api/profile")).ReadAsync<UserDto>();
        Assert.Equal("Lerato", updated.FirstName);
        Assert.Equal("Dlamini", updated.LastName);
        Assert.Equal("0821234567", updated.PhoneNumber);
    }

    [Fact]
    public async Task Profile_UpdateWithMissingName_ReturnsBadRequest()
    {
        var (client, _) = await _factory.LoginAsync("Organiser");

        var response = await client.PutAsJsonAsync("/api/profile", new { firstName = "", lastName = "Smith" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }
}
