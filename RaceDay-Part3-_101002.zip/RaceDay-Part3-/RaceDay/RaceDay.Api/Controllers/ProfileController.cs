using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Extensions;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/profile")]
[Authorize]
public class ProfileController : ControllerBase
{
    private readonly AppDbContext _db;

    public ProfileController(AppDbContext db) => _db = db;

    /// <summary>View the logged-in user's own profile (Organiser and Participant).</summary>
    [HttpGet]
    [ProducesResponseType(typeof(UserDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<UserDto>> Get()
    {
        var user = await _db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.UserId == User.GetUserId());
        return user is null ? NotFound(new ApiError("User not found.")) : Ok(Mappings.ToUserDto(user));
    }

    /// <summary>Update the logged-in user's own profile (first name, last name, phone number, date of birth).</summary>
    [HttpPut]
    [ProducesResponseType(typeof(UserDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<UserDto>> Update(UpdateProfileDto dto)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.UserId == User.GetUserId());
        if (user is null)
            return NotFound(new ApiError("User not found."));

        user.FirstName = dto.FirstName.Trim();
        user.LastName = dto.LastName.Trim();
        user.PhoneNumber = dto.PhoneNumber?.Trim();
        user.DateOfBirth = dto.DateOfBirth;
        await _db.SaveChangesAsync();

        return Ok(Mappings.ToUserDto(user));
    }
}
